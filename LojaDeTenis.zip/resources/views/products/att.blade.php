@extends('layouts.main')
@section('title', 'Cadastro de Produto')
@section('content')

<div class="col-md-10 offset-md-1 dashboard-title-container">
    <h1>Produtos de {{ $usuario->name }}</h1>
</div>
<div class="col-md-10 offset-md-1 dashboard-events-container">
    @if (count($products) > 0)
    <table class="table">
        <thead>
            <tr>
                <th scope=col>#</th>
                <th scope=col>Nome</th>
                <th scope=col>Quantidade no Estoque</th>
                <th scope=col>Ações</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($products as $product)
                <tr>
                    <td scope="row">{{ $loop->index + 1 }}</td>
                    <td scope="row"><a href="/products/{{ $product->id }}">{{ $product->marca }} {{ $product->nome }}</a></td>
                    <td scope="row">{{ $product->qtd }}</td>
                    <td scope="row">
                        <div class="row">
                            <div class="col-md-6"><a href="/products/edit/{{ $product->id }}" class="btn btn-success edit-btn"><ion-icon name="create-outline"></ion-icon>Editar</a></div>
                            <div class="col-md-6">
                                <form action="/products/{{ $product->id }}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">Deletar</button>
                                </form>
                            </div>
                    </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    @else
        <p>Você ainda não tem produtos, <a href="/products/cadastro">Cadastrar produto</a></p>  
    @endif
    
</div>

@endsection