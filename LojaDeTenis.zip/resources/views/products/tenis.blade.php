@extends('layouts.main')
@section('title', 'Loja de Tênis')
@section('content')

<section class="bg-light" style="padding: 30px;">
    <div class="row">
        <div class="col-md-7">
            <div class="row">
                <div class="col-md-6"><img src="/img/events/{{ $product->image }}" style="width:100%;" class="shadow-lg p-3 mb-5 bg-light rounded"></div>
                <div class="col-md-6"><img src="/img/events/{{ $product->image }}" style="width:100%;" class="shadow-lg p-3 mb-5 bg-light rounded"></div>
                <div class="col-md-6"><img src="/img/events/{{ $product->image }}" style="width:100%;" class="shadow-lg p-3 mb-5 bg-light rounded"></div>
                <div class="col-md-6"><img src="/img/events/{{ $product->image }}" style="width:100%;" class="shadow-lg p-3 mb-5 bg-light rounded"></div>
            </div>
        </div>
        <div class="col-md-5" style="padding: 30px;">
            <h2 class = "text-warning">{{ $product->marca }} {{ $product->nome }}</h2>
            <h5 for="" class="text-primary"><ion-icon name="color-palette-sharp" class="text-primary"></ion-icon> {{ $product->cor }}</h5>
            @if ($product->desconto > 0)
                <h5 class = "text-decoration-line-through text-danger">R$ {{ $product->preco }}</h5>
                <h5 class="text-success fw-bolder"><ion-icon name="cash-outline"></ion-icon> R$ {{ $product->preco - ($product->preco * $product->desconto / 100)}} <span class="badge bg-success">{{ $product->desconto }}% OFF</span></h5>
            @else
            <h5 class = "text-success"><ion-icon name="cash-outline"></ion-icon> R$ {{ $product->preco }}</h5>
            @endif
            <div class="row text-center" id="tamclass">
                @foreach ($product->tamanho as $tam)
                    <div class="col-md-5 rounded" id="tamTenis">
                        <label for="">{{ $tam }}</label>
                    </div>
                @endforeach
            </div>
            <h5 class = "text-secondary">Pares disponíveis:
                @if ($product->qtd > 0)
                    {{ $product->qtd}}
                @else
                    Produto Esgotado!!!
                @endif 
            </h5>
            @if ($product->qtd > 0)

                <form action="/products/comprar/{{ $product->id }}" method="POST">
                    @csrf
                    <a href="/products/comprar/{{ $product->id }}" 
                    class="btn btn-primary" 
                    id="product-submit"
                    onclick="product.preventDefault();this.closest('form').submit();">
                    Comprar
                </a>
                </form>
            @endif
        </div>
    </div>
</section>
<footer>
    <p>ERIC SILVEIRA &copy; 2021</p>
</footer>
@endsection
