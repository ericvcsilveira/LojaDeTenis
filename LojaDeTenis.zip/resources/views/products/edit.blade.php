@extends('layouts.main')
@section('title', 'Editando')
@section('content')

<div id="event-create-container" class="col-md-6 offset-md-3">
    <h1 class="text-center">Editando {{ $product->nome }}</h1>
    <form action="/products/update/{{ $product->id }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="title">Modelo:</label>
            <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome do produto" value="{{ $product->nome }}">
        </div>
        <div class="form-group">
            <label for="title">Marca:</label>
            <input type="text" class="form-control" id="marca" name="marca" placeholder="Marca do produto" value="{{ $product->marca }}">
        </div>
        <div class="form-group">
            <label for="title">Preço:</label>
            <input type="number" step="0.01" class="form-control" name="preco" id="preco" placeholder="Ex: 249,90"value="{{ $product->preco }}">
        </div>
        <div class="form-group">
            <label for="title">Cor:</label>
            <input type="text" class="form-control" id="cor" name="cor" placeholder="Cor do produto"value="{{ $product->cor }}">
        </div>   
        <div class="form-group">
            <label for="image">Imagem do Produto:</label>
            <input type="file" id="image" name="image" class="form-control-file">
            <img src="/img/events/{{ $product->image }}" alt="{{ $product->nome }}" class="img-preview">
        </div>
        <div class="form-group">
            <label for="title">Tamanhos disponíveis:</label>
            <div class="form-group">
                <input type="checkbox" name="tamanho[]" value="37"> 37
            </div>
            <div class="form-group">
                <input type="checkbox" name="tamanho[]" value="38"> 38
            </div>
            <div class="form-group">
                <input type="checkbox" name="tamanho[]" value="39"> 39
            </div>
            <div class="form-group">
                <input type="checkbox" name="tamanho[]" value="40"> 40
            </div>
            <div class="form-group">
                <input type="checkbox" name="tamanho[]" value="41"> 41
            </div>
            <div class="form-group">
                <input type="checkbox" name="tamanho[]" value="42"> 42
            </div>
            <div class="form-group">
                <input type="checkbox" name="tamanho[]" value="43"> 43
            </div>
            <div class="form-group">
                <input type="checkbox" name="tamanho[]" value="44"> 44
            </div>
        </div>
        <div class="form-group">
            <label for="title">É um Best Seller?</label>
            <select name="acesso" id="acesso" class="form-control">
                <option value="0">Não</option>
                <option value="1" {{ $product->acesso == 1 ? "selected='selected'" : "" }}>Sim</option>
            </select>
        </div>
        <div class="form-group">
            <label for="title">Quantas unidades disponíveis? </label>
            <input type="number" class="form-control" name="qtd" id="qtd" placeholder="120 pares" value="{{ $product->qtd }}">
        </div>
        <div class="form-group">
            <label for="title">Desconto:</label>
            <input type="number" step="0.01" class="form-control" name="desconto" id="desconto" placeholder="30%" value="{{ $product->desconto }}">
        </div>
         <input type="submit" class="btn btn-primary" value="Atualizar Produto">
    </form>
</div>

@endsection