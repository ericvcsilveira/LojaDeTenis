@extends('layouts.main')
@section('title', 'Administrar Usuários')
@section('content')

<section style="padding: 2rem;">
    <div class="container teste">
        <h1 class="text-center">Administrar Usuários</h1>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Email</th>
                    <th scope="col">Acesso</th>
                    <th scope="col">Deletar</th>
                    </tr>
                </thead>                
                <tbody>
                    @foreach ($usuarios as $user)
                        <tr>
                            <td scope="row">{{ $user->id }}</td>
                            <td>{{ $user->name }}</td>
                            <td>{{ $user->email }}</td>
                            <td>{{ $user->acesso }}</td>
                            <td>
                                <form action="/{{ $user->id }}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger">Deletar</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
    </div>
</section>
@endsection