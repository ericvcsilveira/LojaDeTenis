@extends('layouts.main')
@section('title', 'Dashboard')
@section('content')

<div class="container" style="padding: 30px;">
    <h3 class="text-dark fw-bold">Suas Compras ({{ count($productsByUser) }})</h3>
    <div class="container-fluid p-0">
        <div class="row">
            @if (count($productsByUser) > 0)
                @foreach ($productsByUser as $product)
                <div class="col-md-3 shoes" style="padding: 30px;">                        
                    <img src="img/events/{{ $product->image }}" style="width: 100%;" class="shadow p-3 mb-5 bg-body rounded">
                    <h5 class = "text-dark fw-bolder text-center">{{ $product->marca }} {{ $product->nome }}</h5>

                </div>
                @endforeach
            @else
                <p>Você ainda não possuí nenhuma compra, <a href="/">veja todos os produtos</a></p>
            @endif

@endsection