<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Product;

use App\Models\User;
use Illuminate\Support\Facades\Redirect;

class ProductController extends Controller
{
    public function index(){
        $usuario = auth()->user();

        $search =request('search');

        if($search){

            $products = Product::where([
                ['nome', 'like', '%'.$search.'%']
            ])->get();             

        }else{
            $products = Product::all();
        }

        return view ('welcome', ['products' => $products, 'usuario' => $usuario, 'search' => $search]);

    }

    public function cadastro(){
        $usuario = auth()->user();
        return view('products.cadastro', ['usuario' => $usuario]);
    }

    public function store(Request $request){
        
        $product = new Product;

        $product->nome = $request->nome;
        $product->marca = $request->marca;
        $product->preco = $request->preco;
        $product->cor = $request->cor;
        $product->acesso = $request->acesso;
        $product->tamanho = $request->tamanho;
        $product->desconto = $request->desconto;
        $product->qtd = $request->qtd;
        
        $product->precofinal = $product->preco - (($product->preco * $product->desconto) / 100);

        //imagem 
        if($request->hasFile('image') && $request->file('image')->isValid()){
             
            $requestImage = $request->image;
            $extension = $requestImage->extension();

            $imageName = md5($requestImage->getClientOriginalName(). strtotime("now") . "." . $extension);

            $request->image->move(public_path('img/events'), $imageName);

            $product->image = $imageName;

        }

        $user = auth()->user();
        $product->user_id = $user->id;

        $product->save();

        return redirect('/');
    }

    public function admin(){
        $usuario = auth()->user();
        $usuarios = User::all();
        return view('admin', ['usuario' => $usuario, 'usuarios' => $usuarios]);
    }

    public function destroy($id){
        User::findOrFail($id)->delete();

        return redirect('/admin');
    }

    public function tenis($id){
        $product = Product::findOrFail($id);
        $usuario = auth()->user();

        return view ('products.tenis', ['product' => $product, 'usuario' => $usuario]);

    }

    public function comprarProduto($id){

        $product = Product::findOrFail($id);
        $user = auth()->user();
        $preconovo = $product->precofinal;

        if ($user->carteira >= $preconovo) {

            $user->productsByUser()->attach($id);

            $product->qtd = $product->qtd - 1;

            $user->carteira = $user->carteira - $preconovo;

            $user->save();
    
            $product->save();

            return redirect('/')->with('msg', 'Parabéns, você comprou um ' . $product->nome . " por: " . $preconovo . " reais!!!");
        } else{
            return redirect('/')->with('msg', 'Desculpe, você não tem dinheiro suficiente na carteira para comprar este produto! Deposite clicando no "+" no canto superior direito para efetuar a compra.');
        }
    }

    public function carteira(){
        $usuario = auth()->user();
        return view ('depositar', ['usuario' => $usuario]);
    }

    public function deposito(Request $request){
        $user = auth()->user();

        $user->carteira = $user->carteira + $request->carteira;

        $user->save();
        
        return redirect('/');
    }

    public function dashboard(){
        $usuario = auth()->user();

        $productsByUser = $usuario->productsByUser;

        return view('dashboard', ['usuario' => $usuario, 'productsByUser' => $productsByUser]);
    }

    public function atualizar(){
        $products = Product::all();
        $usuario = auth()->user();

        return view ('products.att', ['products' => $products, 'usuario' => $usuario]);
    }

    public function edit($id){
        $product = Product::findOrFail($id);
        $usuario = auth()->user();

        return view ('products.edit', ['product' => $product, 'usuario' => $usuario]);
    }

    public function update(Request $request){
        Product::findOrFail($request->id)->update($request->all());
        $product = Product::findOrFail($request->id);
        $product->precofinal = $product->preco - (($product->preco * $product->desconto) / 100);
        $product->save();

        return redirect ('/')->with('msg', 'Produto alterado com sucesso!');
    }

    public function destroy2($id){
        Product::findOrFail($id)->delete();

        return redirect('/');
    }

}
