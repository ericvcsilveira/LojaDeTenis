
<?php $__env->startSection('title', 'Eric Silveira'); ?>
<?php $__env->startSection('content'); ?>

<section class="bg-light" style="padding: 30px;">
    <div class="row">
        <div class="col-md-7">
            <div class="row">
                <div class="col-md-6"><img src="/img/events/<?php echo e($product->image); ?>" style="width:100%;" class="shadow-lg p-3 mb-5 bg-light rounded"></div>
                <div class="col-md-6"><img src="/img/events/<?php echo e($product->image); ?>" style="width:100%;" class="shadow-lg p-3 mb-5 bg-light rounded"></div>
                <div class="col-md-6"><img src="/img/events/<?php echo e($product->image); ?>" style="width:100%;" class="shadow-lg p-3 mb-5 bg-light rounded"></div>
                <div class="col-md-6"><img src="/img/events/<?php echo e($product->image); ?>" style="width:100%;" class="shadow-lg p-3 mb-5 bg-light rounded"></div>
            </div>
        </div>
        <div class="col-md-5" style="padding: 30px;">
            <h2 class = "text-warning"><?php echo e($product->marca); ?> <?php echo e($product->nome); ?></h2>
            <h5 for="" class="text-primary"><ion-icon name="color-palette-sharp" class="text-primary"></ion-icon> <?php echo e($product->cor); ?></h5>
            <?php if($product->desconto > 0): ?>
                <h5 class = "text-decoration-line-through text-danger">R$ <?php echo e($product->preco); ?></h5>
                <h5 class="text-success fw-bolder"><ion-icon name="cash-outline"></ion-icon> R$ <?php echo e($product->preco - ($product->preco * $product->desconto / 100)); ?> <span class="badge bg-success"><?php echo e($product->desconto); ?>% OFF</span></h5>
            <?php else: ?>
            <h5 class = "text-success"><ion-icon name="cash-outline"></ion-icon> R$ <?php echo e($product->preco); ?></h5>
            <?php endif; ?>
            <div class="row text-center" id="tamclass">
                <?php $__currentLoopData = $product->tamanho; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-5 rounded" id="tamTenis">
                        <label for=""><?php echo e($tam); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <h5 class = "text-secondary">Pares disponíveis:
                <?php if($product->qtd > 0): ?>
                    <?php echo e($product->qtd); ?>

                <?php else: ?>
                    Produto Esgotado!!!
                <?php endif; ?> 
            </h5>
            <?php if($product->qtd > 0): ?>

                <form action="/products/comprar/<?php echo e($product->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <a href="/products/comprar/<?php echo e($product->id); ?>" 
                    class="btn btn-primary" 
                    id="product-submit"
                    onclick="product.preventDefault();this.closest('form').submit();">
                    Comprar
                </a>
                </form>
            <?php endif; ?>
        </div>
    </div>
</section>
<footer>
    <p>ERIC SILVEIRA &copy; 2021</p>
</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\erica\OneDrive\Área de Trabalho\projeto2laravel\lojaTenis\resources\views/products/tenis.blade.php ENDPATH**/ ?>