<?php $__env->startSection('title', 'Eric Silveira'); ?>
<?php $__env->startSection('content'); ?>


<!-- Cadastro -->
<?php if(auth()->guard()->check()): ?>
    <?php if($usuario->acesso): ?>
    <section class="cadastroSection">
        <div class="container text-center">
            <a href="/products/cadastro"><button class="btn btn-outline-warning">Cadastrar Produto</button></a>
            <a href="/products/att"><button class="btn btn-outline-success">Atualizar Produto</button></a>
        </div>
    </section>
    <?php endif; ?>
<?php endif; ?>
<!-- 1 -->
<section class="bg-light">
    <div class="container">
        <div class="row" style="padding: 30px;">
            <div class="col-lg-6">
                <h1 class="text-dark">JOIN <label class="text-danger">PETE DAVIDSON</label> AND COME SHOP WITH US</h1>

                <h6 class="text-warning">Not everyone can have his comedy, but you can have his shoes...</h6>
                <br>
                <div class="row">
                <div class="col-md-4"><a href="#bestseller"><button class="btn btn-outline-success btn-lg">Best Sellers</button></a></div>
                <div class="col-md-4"><a href="#kyrie"><button class="btn btn-outline-danger btn-lg">See Kyrie 7</button></a></div>
                <div class="col-md-4"><a href="#menshoes"><button class="btn btn-outline-primary btn-lg">Men´s Shoes</button></a></div>
                </div>
                
            </div>
            <div class="col-lg-6">
                <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-indicators">
                      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner rounded">
                      <div class="carousel-item active">
                        <img src="/img/inicial.png" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="/img/inicial2.png" class="d-block w-100" alt="...">
                      </div>
                      <div class="carousel-item">
                        <img src="/img/inicial3.png" class="d-block w-100" alt="...">
                      </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="visually-hidden">Next</span>
                    </button>
                  </div>
            </div>
        </div>
    </div>
</section>

<!-- 2 -->
<section class="bg-light" id="bestseller">
    <div class="container" style="padding: 2rem;">
        <div style="text-align: center;">
            <h1 class="text-dark fw-bold"><ion-icon name="flame-sharp" style="color: orangered"></ion-icon> POPULAR RIGHT NOW <ion-icon name="flame-sharp" style="color: orangered"></ion-icon></h1>
            <h5><ion-icon name="pricetags-sharp" style="color:lightgreen"></ion-icon> The best sellers of the week <ion-icon name="pricetags-sharp" style="color:lightgreen"></ion-icon></h5><br>
        </div>

        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($product->acesso): ?>
                    <div class="col-lg-4 bestseller">
                        <a href="/products/<?php echo e($product->id); ?>">
                            <?php if($product->qtd > 0): ?>
                                <img src="img/events/<?php echo e($product->image); ?>" style="width: 100%;" class="shadow p-3 mb-5 bg-body rounded">
                            <?php else: ?>
                                <img src="img/events/<?php echo e($product->image); ?>" style="width: 100%;   -webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                                filter: grayscale(100%);" class="shadow p-3 mb-5 bg-body rounded">
                            <?php endif; ?>
                        
                        </a>
                        <h6 class="text-warning fw-bold fst-italic"><ion-icon name="flame-sharp" class="text-warning"></ion-icon> Best Seller</h6>
                        <h5 class="text-dark fw-bolder"><?php echo e($product->marca); ?> <?php echo e($product->nome); ?> <?php if($product->qtd == 0): ?> (Esgotado)<?php endif; ?>
                        </h5>
                        <?php if($product->desconto > 0): ?>
                            <h5 class = "text-decoration-line-through">R$ <?php echo e($product->preco); ?></h5>
                            <h5 style="color:red"><ion-icon name="cash-outline" style="color: red"></ion-icon>  R$ <?php echo e($product->precofinal); ?> <span class="badge bg-success"><?php echo e($product->desconto); ?>% OFF</span></h5>
                        <?php else: ?>
                            <h5  style="color:red"><ion-icon name="cash-outline" style="color: red"></ion-icon>  R$ <?php echo e($product->precofinal); ?></h5>
                        <?php endif; ?>
                        <h7 class="text-secondary"><ion-icon name="color-palette-sharp"></ion-icon> <?php echo e($product->cor); ?></h7>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- 3 -->
<section class="bg-light" id="kyrie">
    <br>
    <div class="container text-center">
        <figure class="figure">
            <img src="/img/comp1.png" class="figure-img img-fluid rounded" alt="...">
            <figcaption class="figure-caption">Kyrie 7 collection</figcaption>
        </figure>
    </div>
</section>

<!-- 4 -->
<section class="bg-light" id="menshoes">
    <br>
    <div class="container">
        <h3 class="text-dark fw-bold">Men´s Shoes & collection (<?php echo e(count($products)); ?>)</h3>
        <div class="container-fluid p-0">
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 shoes">
                        <a href="/products/<?php echo e($product->id); ?>">                           
                             <?php if($product->qtd > 0): ?>
                                <img src="img/events/<?php echo e($product->image); ?>" style="width: 100%;" class="shadow p-3 mb-5 bg-body rounded">
                            <?php else: ?>
                                <img src="img/events/<?php echo e($product->image); ?>" style="width: 100%;   -webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                                filter: grayscale(100%);" class="shadow p-3 mb-5 bg-body rounded">
                            <?php endif; ?>
                        </a>
                            <h5 class = "text-dark fw-bolder"><?php echo e($product->marca); ?> <?php echo e($product->nome); ?> <?php if($product->qtd == 0): ?> (Esgotado)<?php endif; ?></h5>
                            <h6 for="" class="text-warning fw-bold"><ion-icon name="color-palette-sharp" class="text-warning"></ion-icon> <?php echo e($product->cor); ?></h6>
                            <?php if($product->desconto > 0): ?>
                                <h5 class = "text-decoration-line-through">R$ <?php echo e($product->preco); ?></h5>
                                <h5 style="color:red"><ion-icon name="cash-outline" style="color: red"></ion-icon>  R$ <?php echo e($product->preco - ($product->preco * $product->desconto / 100)); ?> <span class="badge bg-success"><?php echo e($product->desconto); ?>% OFF</span></h5>
                            <?php else: ?>
                            <h5 style="color:red"><ion-icon name="cash-outline" style="color: red"></ion-icon>  R$ <?php echo e($product->preco); ?></h5>
                            <?php endif; ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<footer>
    <p>ERIC SILVEIRA &copy; 2021</p>
</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\erica\OneDrive\Área de Trabalho\projeto2laravel\lojaTenis\resources\views/welcome.blade.php ENDPATH**/ ?>