
<?php $__env->startSection('title', 'Cadastro de Produto'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-10 offset-md-1 dashboard-title-container">
    <h1>Produtos de <?php echo e($usuario->name); ?></h1>
</div>
<div class="col-md-10 offset-md-1 dashboard-events-container">
    <?php if(count($products) > 0): ?>
    <table class="table">
        <thead>
            <tr>
                <th scope=col>#</th>
                <th scope=col>Nome</th>
                <th scope=col>Quantidade no Estoque</th>
                <th scope=col>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($loop->index + 1); ?></td>
                    <td scope="row"><a href="/products/<?php echo e($product->id); ?>"><?php echo e($product->marca); ?> <?php echo e($product->nome); ?></a></td>
                    <td scope="row"><?php echo e($product->qtd); ?></td>
                    <td scope="row">
                        <div class="row">
                            <div class="col-md-6"><a href="/products/edit/<?php echo e($product->id); ?>" class="btn btn-success edit-btn"><ion-icon name="create-outline"></ion-icon>Editar</a></div>
                            <div class="col-md-6">
                                <form action="/products/<?php echo e($product->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Deletar</button>
                                </form>
                            </div>
                    </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>Você ainda não tem produtos, <a href="/products/cadastro">Cadastrar produto</a></p>  
    <?php endif; ?>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\erica\OneDrive\Área de Trabalho\projeto2laravel\lojaTenis\resources\views/products/att.blade.php ENDPATH**/ ?>