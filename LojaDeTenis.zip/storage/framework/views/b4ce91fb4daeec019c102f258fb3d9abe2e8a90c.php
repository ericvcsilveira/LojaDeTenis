
<?php $__env->startSection('title', 'Cadastro de Produto'); ?>
<?php $__env->startSection('content'); ?>

<div id="event-create-container" class="col-md-6 offset-md-3">
    <h1 class="text-center">Casdastro de Cupom</h1>
    <form action="/products/cupom" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Código do Cupom:</label>
            <input type="text" class="form-control" id="codigo" name="codigo" placeholder="Ex: 20OFFEMTUDO">
        </div>
         <input type="submit" class="btn btn-primary" value="Cadastrar Produto">
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\erica\OneDrive\Área de Trabalho\projeto2laravel\lojaTenis\resources\views/products/cadastrocupom.blade.php ENDPATH**/ ?>