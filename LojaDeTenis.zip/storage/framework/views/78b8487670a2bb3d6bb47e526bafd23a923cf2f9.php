<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Fonte do google -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto" rel="stylesheet">

        <!--Bootstrap -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">    
        <!-- CSS aplicação -->
        <link rel="stylesheet" href="/css/styles.css">
        <script src="/js/scripts.js"></script>
    </head>
    <body>
        <header>
            <nav class="navbar navbar-light navbar-expand-lg">
                <div class="row navrow">
                    <div class="col-md-4">
                        <a class="navbar-brand" href="/">
                            <img src="/img/nike.png"class="img-brand d-inline-block align-top" alt="">
                        </a>
                    </div>
                    <div class="col-md-4">
                        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item active">
                                    <a class="nav-link" href="/">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#"> | </a>
                                </li>
                                <?php if(auth()->guard()->check()): ?>

                                    <?php if($usuario->acesso): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="/admin"> Admin </a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link" href="#"> | </a>
                                        </li>
                                    <?php endif; ?>                                    

                                    <li class="nav-item">
                                        <a class="nav-link" href="#">Olá <?php echo e($usuario->name); ?> </a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="#"> | </a>
                                    </li>

                                    <li class="nav-item">
                                        <form action="/logout" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <a href="/logout" class="nav-link" onclick="event.preventDefault(); this.closest('form').submit();"><ion-icon name="exit-outline"></ion-icon> Sair</a>
                                        </form>
                                    </li>

                                    

                                <?php endif; ?>
                                <?php if(auth()->guard()->guest()): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="/login"> Login </a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="#"> | </a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="/register"> Cadastrar </a>
                                    </li>
                                <?php endif; ?>

                                
                                
                            </ul>
                        </div>
                    </div>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="col-md-4">
                            <div class="collapse navbar-collapse justify-content-center">
                                <ul style="padding: 10px;"  class="navbar-nav">
                                    <li class="nav-item">
                                         
                                        <h4 style="margin: 0 10px;"><a href="/dashboard"><ion-icon name="cart-outline" class="text-secondary"></ion-icon></a></h4>
                                    </li>
                                    <li> | </li>
                                    <li class="nav-item">
                                        <h5  style="margin: 0 10px;"><a href="/depositar"><ion-icon name="add-outline" style="color: red;"></ion-icon></a> <?php echo e($usuario->carteira); ?> BRL </h5>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    <?php endif; ?>

            </nav>
            <nav class="navbar-light navbar-expand-lg">
                <div class="container-fluid text-center" style="width: 30%; padding:20px;">
                    <form class="d-flex" action="/" method="GET">
                            <input class="form-control" type="text" placeholder="Digite o modelo desejado: " id="search" name="search" aria-label="Search">
                            <button class="btn btn-outline-success" type="submit" style=" margin: 0 10px;">Procurar</button>
                    </form>
                </div>

            </nav>

        </header>
        <main>
            <div class="container-fluid">
                <div class="row">
                    <?php if(session('msg')): ?>
                        <p class="msg"> <?php echo e(session('msg')); ?></p>
                    <?php endif; ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </main>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    </body>
    
</html>
<?php /**PATH C:\Users\erica\OneDrive\Área de Trabalho\projeto2laravel\lojaTenis\resources\views/layouts/main.blade.php ENDPATH**/ ?>