
<?php $__env->startSection('title', 'Eric Silveira'); ?>
<?php $__env->startSection('content'); ?>

<div id="event-create-container" class="col-md-6 offset-md-3">
    <h1 class="text-center">Depositar na Carteira </h1>
    <form action="/depositar" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <h4 for="title">Valor:</h4>
            <input type="number" step="0.01" class="form-control" name="carteira" id="carteira" placeholder="Ex: 249,90">
        </div>
         <input type="submit" class="btn btn-success" value="Depositar"> 
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\erica\OneDrive\Área de Trabalho\projeto2laravel\lojaTenis\resources\views/depositar.blade.php ENDPATH**/ ?>