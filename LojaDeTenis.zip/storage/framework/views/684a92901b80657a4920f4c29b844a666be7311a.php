<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="container" style="padding: 30px;">
    <h3 class="text-dark fw-bold">Suas Compras (<?php echo e(count($productsByUser)); ?>)</h3>
    <div class="container-fluid p-0">
        <div class="row">
            <?php if(count($productsByUser) > 0): ?>
                <?php $__currentLoopData = $productsByUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 shoes" style="padding: 30px;">                        
                    <img src="img/events/<?php echo e($product->image); ?>" style="width: 100%;" class="shadow p-3 mb-5 bg-body rounded">
                    <h5 class = "text-dark fw-bolder text-center"><?php echo e($product->marca); ?> <?php echo e($product->nome); ?></h5>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>Você ainda não possuí nenhuma compra, <a href="/">veja todos os produtos</a></p>
            <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\erica\OneDrive\Área de Trabalho\projetos\projeto2laravel\lojaTenis\resources\views/dashboard.blade.php ENDPATH**/ ?>