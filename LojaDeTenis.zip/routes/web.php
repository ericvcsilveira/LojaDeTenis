<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [ProductController::class, 'index']);
Route::get('/products/cadastro', [ProductController::class, 'cadastro'])->middleware('auth');
Route::get('/products/att', [ProductController::class, 'atualizar'])->middleware('auth');
Route::post('/products', [ProductController::class, 'store']);
Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');

Route::get('/admin', [ProductController::class, 'admin'])->middleware('auth');
Route::delete('/{id}', [ProductController::class, 'destroy'])->middleware('auth');
Route::get('/products/{id}', [ProductController::class, 'tenis']);

Route::get('/products/comprar/{id}',  [ProductController::class, 'comprarProduto'])->middleware('auth');
Route::get('/depositar', [ProductController::class, 'carteira'])->middleware('auth');
Route::post('/depositar', [ProductController::class, 'deposito']);
Route::get('/dashboard', [ProductController::class, 'dashboard'])->middleware('auth');

Route::get('/products/edit/{id}', [ProductController::class, 'edit'])->middleware('auth');
Route::put('/products/update/{id}', [ProductController::class, 'update'])->middleware('auth');
Route::delete('/products/{id}', [ProductController::class, 'destroy2'])->middleware('auth');
